from MpApi.Module import Module

m = Module(file="sdata/exhibit20222.xml")
m.validate()