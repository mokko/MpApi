Let's put tests that require a connection to a working client here and not run them
by default when running the test suite. So far I am planing to run these tests 
manually only.