"""An unofficial client for MuseumPlus's API"""

__version__ = "0.1"
