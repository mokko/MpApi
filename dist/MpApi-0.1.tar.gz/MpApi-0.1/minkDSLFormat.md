#DSL Format for jobs.dsl

\# comment
job label: 
\# colon indicates that expression is job label
\# job labels might not allow spaces (todo, check)
\# identation is important 
\# identation by tabulator or 4 spaces
	mink command param1 param2 param3
\# Which commands are possible? see Mink.py